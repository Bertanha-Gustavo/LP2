﻿namespace WinFormsApp1
{
    partial class Atividade2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtBoxNumN = new TextBox();
            label1 = new Label();
            btnCalcH = new Button();
            SuspendLayout();
            // 
            // txtBoxNumN
            // 
            txtBoxNumN.Font = new Font("Segoe UI", 14F);
            txtBoxNumN.Location = new Point(27, 166);
            txtBoxNumN.Name = "txtBoxNumN";
            txtBoxNumN.Size = new Size(195, 39);
            txtBoxNumN.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(27, 107);
            label1.Name = "label1";
            label1.Size = new Size(195, 28);
            label1.TabIndex = 1;
            label1.Text = "Forneça o número N:";
            // 
            // btnCalcH
            // 
            btnCalcH.Location = new Point(27, 253);
            btnCalcH.Name = "btnCalcH";
            btnCalcH.Size = new Size(185, 128);
            btnCalcH.TabIndex = 2;
            btnCalcH.Text = "Calcular o número H";
            btnCalcH.UseVisualStyleBackColor = true;
            btnCalcH.Click += btnCalcH_Click;
            // 
            // Atividade2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCalcH);
            Controls.Add(label1);
            Controls.Add(txtBoxNumN);
            Name = "Atividade2";
            Text = "Atividade2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtBoxNumN;
        private Label label1;
        private Button btnCalcH;
    }
}