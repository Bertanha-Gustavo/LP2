﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Atividade4 : Form
    {
        public Atividade4()
        {
            InitializeComponent();
        }

        private void btnCalcSalario_Click(object sender, EventArgs e)
        {
            string nome;
            string matricula;
            int producao;
            double salarioBase; 
            double gratificacao;
            double salarioBruto;

            
            double b = 0;
            double c = 0;
            double d = 0;

            
            nome = txtNome.Text;
            matricula = txtMatricula.Text;

            
            producao = int.Parse(txtProducao.Text);
            salarioBase = double.Parse(txtSalario.Text);
            gratificacao = double.Parse(txtGratificacao.Text);

            

            if (producao >= 100)
            {
                b = 1;
            }
            else
            {
                b = 0;
            }

            if (producao >= 120)
            {
                c = 1;
            }
            else
            {
                c = 0;
            }

            if (producao >= 150)
            {
                d = 1;
            }
            else
            {
                d = 0;
            }

            
            double parteDosAdicionais = (0.05 * b) + (0.1 * c) + (0.1 * d);
            double valorExtraSalario = salarioBase * parteDosAdicionais;

            
            salarioBruto = salarioBase + valorExtraSalario + gratificacao;

            
            if (salarioBruto > 7000)
            {
                
                if (producao >= 150 && gratificacao > 0)
                {
                    
                }
                else
                {
                    
                    salarioBruto = 7000;
                }
            }

            
            MessageBox.Show("O Salário Bruto do funcionário " + nome + " é: R$ " + salarioBruto.ToString("N2"));
        }
    }
}
