﻿namespace WinFormsApp1
{
    partial class Atividade4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNome = new TextBox();
            txtMatricula = new TextBox();
            txtProducao = new TextBox();
            txtSalario = new TextBox();
            txtGratificacao = new TextBox();
            lblNome = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            btnCalcSalario = new Button();
            SuspendLayout();
            // 
            // txtNome
            // 
            txtNome.Font = new Font("Segoe UI", 12F);
            txtNome.Location = new Point(228, 46);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(209, 34);
            txtNome.TabIndex = 0;
            // 
            // txtMatricula
            // 
            txtMatricula.Font = new Font("Segoe UI", 12F);
            txtMatricula.Location = new Point(228, 95);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(209, 34);
            txtMatricula.TabIndex = 1;
            // 
            // txtProducao
            // 
            txtProducao.Font = new Font("Segoe UI", 12F);
            txtProducao.Location = new Point(228, 155);
            txtProducao.Name = "txtProducao";
            txtProducao.Size = new Size(209, 34);
            txtProducao.TabIndex = 2;
            // 
            // txtSalario
            // 
            txtSalario.Font = new Font("Segoe UI", 12F);
            txtSalario.Location = new Point(228, 210);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(209, 34);
            txtSalario.TabIndex = 3;
            // 
            // txtGratificacao
            // 
            txtGratificacao.Font = new Font("Segoe UI", 12F);
            txtGratificacao.Location = new Point(228, 265);
            txtGratificacao.Name = "txtGratificacao";
            txtGratificacao.Size = new Size(209, 34);
            txtGratificacao.TabIndex = 4;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Segoe UI", 12F);
            lblNome.Location = new Point(12, 52);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(158, 28);
            lblNome.TabIndex = 5;
            lblNome.Text = "Digite seu nome:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.Location = new Point(12, 101);
            label2.Name = "label2";
            label2.Size = new Size(189, 28);
            label2.TabIndex = 6;
            label2.Text = "Digite sua matrícula:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(12, 155);
            label3.Name = "label3";
            label3.Size = new Size(193, 28);
            label3.TabIndex = 7;
            label3.Text = "Digite sua produção:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F);
            label4.Location = new Point(12, 210);
            label4.Name = "label4";
            label4.Size = new Size(165, 28);
            label4.TabIndex = 8;
            label4.Text = "Digite seu salário:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F);
            label5.Location = new Point(12, 265);
            label5.Name = "label5";
            label5.Size = new Size(210, 28);
            label5.TabIndex = 9;
            label5.Text = "Digite sua gratificação:";
            // 
            // btnCalcSalario
            // 
            btnCalcSalario.Font = new Font("Segoe UI", 12F);
            btnCalcSalario.Location = new Point(532, 265);
            btnCalcSalario.Name = "btnCalcSalario";
            btnCalcSalario.Size = new Size(209, 173);
            btnCalcSalario.TabIndex = 10;
            btnCalcSalario.Text = "Calcular salário bruto";
            btnCalcSalario.UseVisualStyleBackColor = true;
            btnCalcSalario.Click += btnCalcSalario_Click;
            // 
            // Atividade4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCalcSalario);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(lblNome);
            Controls.Add(txtGratificacao);
            Controls.Add(txtSalario);
            Controls.Add(txtProducao);
            Controls.Add(txtMatricula);
            Controls.Add(txtNome);
            Name = "Atividade4";
            Text = "Atividade4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNome;
        private TextBox txtMatricula;
        private TextBox txtProducao;
        private TextBox txtSalario;
        private TextBox txtGratificacao;
        private Label lblNome;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button btnCalcSalario;
    }
}