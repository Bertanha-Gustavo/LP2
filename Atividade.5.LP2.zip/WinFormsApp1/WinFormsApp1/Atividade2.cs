﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Atividade2 : Form
    {
        public Atividade2()
        {
            InitializeComponent();
        }

        private void btnCalcH_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtBoxNumN.Text, out int n))
            {

                if (n > 0)
                {
                    double h = 0;


                    for (int i = 1; i <= n; i++)
                    {

                        h = h + (1.0 / i);
                    }


                    MessageBox.Show("O valor de H para N = " + n + " é: " + h.ToString("F4"), "Resultado");
                }
                else
                {
                    MessageBox.Show("Por favor, digite um número maior que zero.");
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira um número inteiro válido.");
            }
        }
    }

}
