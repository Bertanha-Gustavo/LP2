﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Atividade1 : Form
    {
        public Atividade1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string texto = rchTxtBox1.Text;
            int contador = 0;

            
            for (int i = 0; i < texto.Length; i++)
            {
                if (texto[i] == ' ')
                {
                    contador++;
                }
            }

            MessageBox.Show("A frase contém " + contador + " espaços em branco.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string texto = rchTxtBox1.Text;
            int contador = 0;

            
            foreach (char letra in texto)
            {
                if (letra == 'R' || letra == 'r')
                {
                    contador++;
                }
            }

            MessageBox.Show("A letra 'R' aparece " + contador + " vezes.");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string texto = rchTxtBox1.Text;
            int contador = 0;
            int i = 0;

            // Loop WHILE: Percorre até o penúltimo caractere
            // (texto.Length - 1) evita que o código tente ler além do fim da frase
            while (i < texto.Length - 1)
            {
                // Converte para minúsculo para comparar 'R' com 'r', por exemplo
                char atual = char.ToLower(texto[i]);
                char proxima = char.ToLower(texto[i + 1]);

                if (atual == proxima && char.IsLetter(atual))
                {
                    contador++;
                }

                i++;
            }

            MessageBox.Show("Existem " + contador + " letras repetidas seguidas.");
        }
    }
}
