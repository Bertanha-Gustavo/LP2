﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Atividade3 : Form
    {
        public Atividade3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string frase = richTextBox1.Text;

            
            if (frase.Length > 50)
            {
                MessageBox.Show("Por favor, digite uma frase com no máximo 50 caracteres.");
                return; 
            }

            if (string.IsNullOrWhiteSpace(frase))
            {
                MessageBox.Show("Por favor, digite uma frase para verificar.");
                return;
            }

           
            string fraseLimpa = RemoverAcentos(frase);
            fraseLimpa = fraseLimpa.Replace(" ", "").ToLower();

            
            bool ehPalindromo = true;
            int tamanho = fraseLimpa.Length;

            
            for (int i = 0; i < tamanho / 2; i++)
            {
                
                if (fraseLimpa[i] != fraseLimpa[tamanho - 1 - i])
                {
                    ehPalindromo = false;
                    break; 
                }
            }

            
            if (ehPalindromo)
            {
                MessageBox.Show("Sim! A frase é um palíndromo.", "Resultado");
            }
            else
            {
                MessageBox.Show("Não, a frase não é um palíndromo.", "Resultado");
            }
        }

        
        private string RemoverAcentos(string texto)
        {
            string comAcentos = "ÁÀÂÃÉÈÊÍÌÎÓÒÔÕÚÙÛÇáàâãéèêíìîóòôõúùûç";
            string semAcentos = "AAAAEEEIIIOOOOUUUCaaaaeeeiiioooouuuc";

            
            for (int i = 0; i < comAcentos.Length; i++)
            {
                texto = texto.Replace(comAcentos[i].ToString(), semAcentos[i].ToString());
            }

            return texto;
        }
    }
}


