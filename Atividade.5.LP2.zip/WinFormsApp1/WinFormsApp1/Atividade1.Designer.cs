﻿namespace WinFormsApp1
{
    partial class Atividade1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchTxtBox1 = new RichTextBox();
            lblTexto = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // rchTxtBox1
            // 
            rchTxtBox1.Location = new Point(35, 52);
            rchTxtBox1.Name = "rchTxtBox1";
            rchTxtBox1.Size = new Size(628, 172);
            rchTxtBox1.TabIndex = 0;
            rchTxtBox1.Text = "";
            // 
            // lblTexto
            // 
            lblTexto.AutoSize = true;
            lblTexto.Location = new Point(35, 29);
            lblTexto.Name = "lblTexto";
            lblTexto.Size = new Size(45, 20);
            lblTexto.TabIndex = 1;
            lblTexto.Text = "Texto";
            // 
            // button1
            // 
            button1.Location = new Point(35, 314);
            button1.Name = "button1";
            button1.Size = new Size(115, 95);
            button1.TabIndex = 2;
            button1.Text = "Contagem de espaços";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(200, 314);
            button2.Name = "button2";
            button2.Size = new Size(114, 95);
            button2.TabIndex = 3;
            button2.Text = "Contagem de R's";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(365, 314);
            button3.Name = "button3";
            button3.Size = new Size(128, 95);
            button3.TabIndex = 4;
            button3.Text = "Letras repetidas na frase";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Atividade1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(lblTexto);
            Controls.Add(rchTxtBox1);
            Name = "Atividade1";
            Text = "Atividade1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox rchTxtBox1;
        private Label lblTexto;
        private Button button1;
        private Button button2;
        private Button button3;
    }
}