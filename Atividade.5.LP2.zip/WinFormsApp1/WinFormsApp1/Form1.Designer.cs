﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            atividade1ToolStripMenuItem = new ToolStripMenuItem();
            atividade2ToolStripMenuItem = new ToolStripMenuItem();
            atividade3ToolStripMenuItem = new ToolStripMenuItem();
            atividade4ToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { atividade1ToolStripMenuItem, atividade2ToolStripMenuItem, atividade3ToolStripMenuItem, atividade4ToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // atividade1ToolStripMenuItem
            // 
            atividade1ToolStripMenuItem.Name = "atividade1ToolStripMenuItem";
            atividade1ToolStripMenuItem.Size = new Size(99, 24);
            atividade1ToolStripMenuItem.Text = "Atividade 1";
            atividade1ToolStripMenuItem.Click += atividade1ToolStripMenuItem_Click;
            // 
            // atividade2ToolStripMenuItem
            // 
            atividade2ToolStripMenuItem.Name = "atividade2ToolStripMenuItem";
            atividade2ToolStripMenuItem.Size = new Size(99, 24);
            atividade2ToolStripMenuItem.Text = "Atividade 2";
            atividade2ToolStripMenuItem.Click += atividade2ToolStripMenuItem_Click;
            // 
            // atividade3ToolStripMenuItem
            // 
            atividade3ToolStripMenuItem.Name = "atividade3ToolStripMenuItem";
            atividade3ToolStripMenuItem.Size = new Size(99, 24);
            atividade3ToolStripMenuItem.Text = "Atividade 3";
            atividade3ToolStripMenuItem.Click += atividade3ToolStripMenuItem_Click;
            // 
            // atividade4ToolStripMenuItem
            // 
            atividade4ToolStripMenuItem.Name = "atividade4ToolStripMenuItem";
            atividade4ToolStripMenuItem.Size = new Size(99, 24);
            atividade4ToolStripMenuItem.Text = "Atividade 4";
            atividade4ToolStripMenuItem.Click += atividade4ToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem atividade1ToolStripMenuItem;
        private ToolStripMenuItem atividade2ToolStripMenuItem;
        private ToolStripMenuItem atividade3ToolStripMenuItem;
        private ToolStripMenuItem atividade4ToolStripMenuItem;
    }
}
