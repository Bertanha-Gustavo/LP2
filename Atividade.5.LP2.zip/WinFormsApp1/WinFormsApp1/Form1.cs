using static System.Windows.Forms.DataFormats;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void atividade1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Atividade1 tela = new Atividade1();
            tela.MdiParent = this;
            tela.Show();
        }

        private void atividade2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Atividade2 tela = new Atividade2();
            tela.MdiParent = this;
            tela.Show();
        }

        private void atividade3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Atividade3 tela = new Atividade3();
            tela.MdiParent = this;
            tela.Show();
        }

        private void atividade4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Atividade4 tela = new Atividade4();
            tela.MdiParent = this;
            tela.Show();
        }
    }
}
