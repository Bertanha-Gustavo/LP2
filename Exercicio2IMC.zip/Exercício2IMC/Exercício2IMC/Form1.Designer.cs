﻿namespace Exercício2IMC
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            mskbxPeso = new MaskedTextBox();
            mskbxAltura = new MaskedTextBox();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(146, 280);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(112, 34);
            btnCalcular.TabIndex = 0;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(298, 280);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 1;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(451, 280);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 2;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(70, 79);
            label1.Name = "label1";
            label1.Size = new Size(92, 25);
            label1.TabIndex = 3;
            label1.Text = "Peso atual";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(70, 156);
            label2.Name = "label2";
            label2.Size = new Size(59, 25);
            label2.TabIndex = 4;
            label2.Text = "Altura";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(70, 227);
            label3.Name = "label3";
            label3.Size = new Size(44, 25);
            label3.TabIndex = 5;
            label3.Text = "IMC";
            // 
            // mskbxPeso
            // 
            mskbxPeso.Location = new Point(210, 79);
            mskbxPeso.Mask = "000.00";
            mskbxPeso.Name = "mskbxPeso";
            mskbxPeso.Size = new Size(150, 31);
            mskbxPeso.TabIndex = 6;
            mskbxPeso.Validated += mskbxPeso_Validated;
            // 
            // mskbxAltura
            // 
            mskbxAltura.Location = new Point(210, 156);
            mskbxAltura.Mask = "0.00";
            mskbxAltura.Name = "mskbxAltura";
            mskbxAltura.Size = new Size(150, 31);
            mskbxAltura.TabIndex = 7;
            mskbxAltura.Validated += mskbxAltura_Validated;
            // 
            // textBox1
            // 
            textBox1.Enabled = false;
            textBox1.Location = new Point(210, 224);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(150, 31);
            textBox1.TabIndex = 8;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBox1);
            Controls.Add(mskbxAltura);
            Controls.Add(mskbxPeso);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Name = "Form1";
            Text = "v";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
        private Label label1;
        private Label label2;
        private Label label3;
        private MaskedTextBox mskbxPeso;
        private MaskedTextBox mskbxAltura;
        private TextBox textBox1;
    }
}
