using System.Diagnostics.Eventing.Reader;

namespace Exercício2IMC
{
    public partial class Form1 : Form
    {
        double Peso;
        double Altura;
        double IMC;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Text = "";
            mskbxPeso.Text = "";
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out Peso) || (Peso <= 0))
            {
                MessageBox.Show("Peso inválido");
                mskbxPeso.Focus();
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out Altura) || (Altura <= 0))
            {
                MessageBox.Show("Altura inválida");
                mskbxAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = Peso / Math.Pow(Altura, 2);

            IMC = Math.Round(IMC, 1);

            if (IMC < 18.5)
                MessageBox.Show("Magreza");

            else
                if (IMC <= 24.9)
                MessageBox.Show("Normal");
            else
                if (IMC <= 29.9)
                MessageBox.Show("Sobrepeso");
            else
                if (IMC <= 39.9)
                MessageBox.Show("Obesidade");
            else
                MessageBox.Show("Obesidade Grave");
               
        }
    }
}
