﻿namespace Exercício1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumero1 = new Label();
            lblNumero2 = new Label();
            label3 = new Label();
            label4 = new Label();
            lblResultado = new Label();
            txtNumero1 = new TextBox();
            txtNumero2 = new TextBox();
            txtResultado = new TextBox();
            btnLimpar = new Button();
            btnSair = new Button();
            btnMais = new Button();
            btnMenos = new Button();
            btnMult = new Button();
            btnDiv = new Button();
            SuspendLayout();
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNumero1.Location = new Point(53, 65);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(111, 30);
            lblNumero1.TabIndex = 0;
            lblNumero1.Text = "Número 1";
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNumero2.Location = new Point(53, 142);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(111, 30);
            lblNumero2.TabIndex = 1;
            lblNumero2.Text = "Número 2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(379, 221);
            label3.Name = "label3";
            label3.Size = new Size(0, 25);
            label3.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(387, 229);
            label4.Name = "label4";
            label4.Size = new Size(0, 25);
            label4.TabIndex = 3;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblResultado.Location = new Point(53, 246);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(107, 30);
            lblResultado.TabIndex = 4;
            lblResultado.Text = "Resultado";
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(179, 63);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(220, 31);
            txtNumero1.TabIndex = 5;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(179, 139);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(219, 31);
            txtNumero2.TabIndex = 6;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(179, 243);
            txtResultado.Name = "txtResultado";
            txtResultado.ReadOnly = true;
            txtResultado.Size = new Size(220, 31);
            txtResultado.TabIndex = 7;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(547, 63);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 58);
            btnLimpar.TabIndex = 8;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(547, 139);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 57);
            btnSair.TabIndex = 9;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnMais
            // 
            btnMais.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnMais.Location = new Point(53, 317);
            btnMais.Name = "btnMais";
            btnMais.Size = new Size(112, 71);
            btnMais.TabIndex = 10;
            btnMais.Text = "+";
            btnMais.UseVisualStyleBackColor = true;
            btnMais.Click += btnMais_Click;
            // 
            // btnMenos
            // 
            btnMenos.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnMenos.Location = new Point(216, 317);
            btnMenos.Name = "btnMenos";
            btnMenos.Size = new Size(112, 71);
            btnMenos.TabIndex = 11;
            btnMenos.Text = "-";
            btnMenos.UseVisualStyleBackColor = true;
            btnMenos.Click += btnMenos_Click;
            // 
            // btnMult
            // 
            btnMult.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnMult.Location = new Point(379, 317);
            btnMult.Name = "btnMult";
            btnMult.Size = new Size(112, 71);
            btnMult.TabIndex = 12;
            btnMult.Text = "*";
            btnMult.UseVisualStyleBackColor = true;
            btnMult.Click += btnMult_Click;
            // 
            // btnDiv
            // 
            btnDiv.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDiv.Location = new Point(547, 317);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(112, 71);
            btnDiv.TabIndex = 13;
            btnDiv.Text = "/";
            btnDiv.UseVisualStyleBackColor = true;
            btnDiv.Click += btnDiv_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnDiv);
            Controls.Add(btnMult);
            Controls.Add(btnMenos);
            Controls.Add(btnMais);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(txtResultado);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Controls.Add(lblResultado);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNumero1;
        private Label lblNumero2;
        private Label label3;
        private Label label4;
        private Label lblResultado;
        private TextBox txtNumero1;
        private TextBox txtNumero2;
        private TextBox txtResultado;
        private Button btnLimpar;
        private Button btnSair;
        private Button btnMais;
        private Button btnMenos;
        private Button btnMult;
        private Button btnDiv;
    }
}
