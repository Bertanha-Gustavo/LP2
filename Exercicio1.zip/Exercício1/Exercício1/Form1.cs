using System.Windows.Forms;

namespace Exercício1
{
    public partial class Form1 : Form
    {
        double Numero1;
        double Numero2;
        double Resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out Numero1))
            {
                MessageBox.Show("Número inválido!");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out Numero2))
            {
                MessageBox.Show("Número inválido!");
                txtNumero2.Focus();
            }
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (Numero2 == 0)
            {
                MessageBox.Show("Não podemos dividir por zero");
                txtNumero2.Text = "";
                txtNumero2.Focus();
            }
            else
            {
                Resultado = Numero1 / Numero2;
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = "0";
            txtNumero2.Text = "0";
            txtResultado.Text = "0";
        }
    }
}
