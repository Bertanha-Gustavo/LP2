﻿namespace ATIVIDADE_3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            btnExe = new Button();
            btnLimpar = new Button();
            txtPrimVert = new TextBox();
            txtSegVert = new TextBox();
            txtTerVert = new TextBox();
            lbl1Vert = new Label();
            lbl2Vert = new Label();
            lblVert = new Label();
            btnSair = new Button();
            pictureBox1 = new PictureBox();
            lblResultado = new Label();
            txtResultado = new TextBox();
            errorA = new ErrorProvider(components);
            errorC = new ErrorProvider(components);
            errorB = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorA).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorC).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorB).BeginInit();
            SuspendLayout();
            // 
            // btnExe
            // 
            btnExe.Location = new Point(27, 369);
            btnExe.Name = "btnExe";
            btnExe.Size = new Size(112, 46);
            btnExe.TabIndex = 0;
            btnExe.Text = "Executar";
            btnExe.UseVisualStyleBackColor = true;
            btnExe.Click += btnExe_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(194, 369);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 46);
            btnLimpar.TabIndex = 1;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // txtPrimVert
            // 
            txtPrimVert.Location = new Point(167, 75);
            txtPrimVert.Name = "txtPrimVert";
            txtPrimVert.Size = new Size(182, 31);
            txtPrimVert.TabIndex = 2;
            txtPrimVert.Validated += txtPrimVert_Validated;
            // 
            // txtSegVert
            // 
            txtSegVert.Location = new Point(167, 151);
            txtSegVert.Name = "txtSegVert";
            txtSegVert.Size = new Size(182, 31);
            txtSegVert.TabIndex = 3;
            txtSegVert.Validated += txtSegVert_Validated;
            // 
            // txtTerVert
            // 
            txtTerVert.Location = new Point(167, 223);
            txtTerVert.Name = "txtTerVert";
            txtTerVert.Size = new Size(182, 31);
            txtTerVert.TabIndex = 4;
            txtTerVert.Validated += txtTerVert_Validated;
            // 
            // lbl1Vert
            // 
            lbl1Vert.AutoSize = true;
            lbl1Vert.Location = new Point(27, 75);
            lbl1Vert.Name = "lbl1Vert";
            lbl1Vert.Size = new Size(134, 25);
            lbl1Vert.TabIndex = 5;
            lbl1Vert.Text = "Primeiro vértice";
            // 
            // lbl2Vert
            // 
            lbl2Vert.AutoSize = true;
            lbl2Vert.Location = new Point(27, 157);
            lbl2Vert.Name = "lbl2Vert";
            lbl2Vert.Size = new Size(140, 25);
            lbl2Vert.TabIndex = 6;
            lbl2Vert.Text = "Segundo vértice";
            // 
            // lblVert
            // 
            lblVert.AutoSize = true;
            lblVert.Location = new Point(27, 229);
            lblVert.Name = "lblVert";
            lblVert.Size = new Size(128, 25);
            lblVert.TabIndex = 7;
            lblVert.Text = "Terceiro vértice";
            // 
            // btnSair
            // 
            btnSair.Location = new Point(365, 369);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 46);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(365, 75);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(423, 179);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(27, 295);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(90, 25);
            lblResultado.TabIndex = 10;
            lblResultado.Text = "Resultado";
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(144, 295);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(205, 31);
            txtResultado.TabIndex = 11;
            // 
            // errorA
            // 
            errorA.ContainerControl = this;
            // 
            // errorC
            // 
            errorC.ContainerControl = this;
            // 
            // errorB
            // 
            errorB.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtResultado);
            Controls.Add(lblResultado);
            Controls.Add(pictureBox1);
            Controls.Add(btnSair);
            Controls.Add(lblVert);
            Controls.Add(lbl2Vert);
            Controls.Add(lbl1Vert);
            Controls.Add(txtTerVert);
            Controls.Add(txtSegVert);
            Controls.Add(txtPrimVert);
            Controls.Add(btnLimpar);
            Controls.Add(btnExe);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorA).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorC).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorB).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnExe;
        private Button btnLimpar;
        private TextBox txtPrimVert;
        private TextBox txtSegVert;
        private TextBox txtTerVert;
        private Label lbl1Vert;
        private Label lbl2Vert;
        private Label lblVert;
        private Button btnSair;
        private PictureBox pictureBox1;
        private Label lblResultado;
        private TextBox txtResultado;
        private ErrorProvider errorA;
        private ErrorProvider errorProvider3;
        private ErrorProvider errorProvider4;
        private ErrorProvider errorProvider5;
        private ErrorProvider errorC;
        private ErrorProvider errorB;
    }
}
