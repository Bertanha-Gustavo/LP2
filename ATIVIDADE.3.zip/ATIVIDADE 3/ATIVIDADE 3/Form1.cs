namespace ATIVIDADE_3
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtPrimVert_Validated(object sender, EventArgs e)
        {
            try
            {
                valorA = Convert.ToDouble(txtPrimVert.Text);
            }
            catch
            {
                errorA.SetError(txtPrimVert, "Valor A inv�lido");
            }
        }

        private void txtSegVert_Validated(object sender, EventArgs e)
        {
            try
            {
                valorB = Convert.ToDouble(txtSegVert.Text);
            }
            catch
            {
                errorB.SetError(txtSegVert, "Valor A inv�lido");
            }
        }

        private void txtTerVert_Validated(object sender, EventArgs e)
        {
            try
            {
                valorC = Convert.ToDouble(txtTerVert.Text);
            }
            catch
            {
                errorB.SetError(txtTerVert, "Valor A inv�lido");
            }
        }

        private void btnExe_Click(object sender, EventArgs e)
        {
            if ((valorA < (valorB + valorC)) && (valorA > (Math.Abs(valorB - valorC))) && (valorA < (valorB + valorC)) && (valorB > (Math.Abs(valorA - valorC))) && (valorA > (Math.Abs(valorB - valorC))) && (valorC < (valorA + valorB)))
            {
                if (valorA == valorB && valorB == valorC)
                {
                    MessageBox.Show("O tri�ngulo � Equil�tero");
                }
                else
                {
                    if (valorA == valorB || valorB == valorC || valorC == valorA)
                    {
                        MessageBox.Show("O tri�ngulo � Is�sceles");
                    }
                    else
                    {
                        MessageBox.Show("O Tri�ngulo � Escaleno");
                    }
                }
            }
            else
            {
                MessageBox.Show("Esses valores n�o formam um tri�ngulo");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            valorA = 0;
            valorB = 0;
            valorC = 0;
            txtPrimVert.Clear();
            txtSegVert.Clear();
            txtTerVert.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
