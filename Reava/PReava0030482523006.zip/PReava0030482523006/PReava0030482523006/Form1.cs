﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PReava0030482523006
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        double[] MatrizNum = new double[10];
        double[] MatrizResult = new double[10];

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string aux;
            for (int i = 0; i < 10; i++)
            {
                aux = Interaction.InputBox($"Digite o valor da posicao {i + 1}");
                if (!Double.TryParse(aux, out MatrizNum[i]) || MatrizNum[i] < 0)
                {
                    MessageBox.Show("Valor inválido");
                    i--;
                }
                else
                {
                    if (((i+1) % 2) == 0)
                    {
                        MatrizResult[i] = MatrizNum[i] * 4;
                    }
                    else
                    {
                        MatrizResult[i] = MatrizNum[i] + 4;
                    }
                }
            }

            for (int i = 0; i < 10; i++)
            {
                lstBxValores.Items.Add("Posição "+ (i+1) + " da Matriz A: " +MatrizNum[i].ToString("n2") + " Matriz B: " + MatrizResult[i].ToString("n2"));
                lstBxValores.Items.Add('\n');
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstBxValores.Items.Clear();
        }
    }
}
